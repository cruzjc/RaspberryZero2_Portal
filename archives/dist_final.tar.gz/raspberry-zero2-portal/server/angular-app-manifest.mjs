
export default {
  bootstrap: () => import('./main.server.mjs').then(m => m.default),
  inlineCriticalCss: true,
  baseHref: '/',
  locale: undefined,
  routes: [
  {
    "renderMode": 2,
    "route": "/news"
  },
  {
    "renderMode": 2,
    "route": "/news-settings"
  },
  {
    "renderMode": 2,
    "route": "/admin"
  }
],
  entryPointToBrowserMapping: undefined,
  assets: {
    'index.csr.html': {size: 504, hash: 'c11ce724acee0795a02d66c0e89d58045d831a58a9452f7ff9ec27435548fad1', text: () => import('./assets-chunks/index_csr_html.mjs').then(m => m.default)},
    'index.server.html': {size: 1017, hash: 'b1f9e41c27871e22597a96d90f1e0fe78f46b85b55c5aa6e34ed02c7d0b6021b', text: () => import('./assets-chunks/index_server_html.mjs').then(m => m.default)},
    'news-settings/index.html': {size: 17685, hash: '9a08cd84d2339500be829db0eedb90cdbb9d5dc7b31d5b934c047a91c4455441', text: () => import('./assets-chunks/news-settings_index_html.mjs').then(m => m.default)},
    'admin/index.html': {size: 15884, hash: '6859d7595d76c0013ebcb8279e79407e568f2af7f7e37d22856819eb38b2f322', text: () => import('./assets-chunks/admin_index_html.mjs').then(m => m.default)},
    'news/index.html': {size: 19505, hash: '4224834f707b3d4cc0edd6df20f1085eaf85555a105ca56e703654835f1e52b4', text: () => import('./assets-chunks/news_index_html.mjs').then(m => m.default)},
    'styles-5INURTSO.css': {size: 0, hash: 'menYUTfbRu8', text: () => import('./assets-chunks/styles-5INURTSO_css.mjs').then(m => m.default)}
  },
};
