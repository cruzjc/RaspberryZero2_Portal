
export default {
  bootstrap: () => import('./main.server.mjs').then(m => m.default),
  inlineCriticalCss: true,
  baseHref: '/',
  locale: undefined,
  routes: [
  {
    "renderMode": 2,
    "route": "/news"
  },
  {
    "renderMode": 2,
    "route": "/news-settings"
  },
  {
    "renderMode": 2,
    "route": "/admin"
  }
],
  entryPointToBrowserMapping: undefined,
  assets: {
    'index.csr.html': {size: 504, hash: 'd351ab39b633af03c99bb663c03988edee45ba91e5de15d11f11e68ffedc4c48', text: () => import('./assets-chunks/index_csr_html.mjs').then(m => m.default)},
    'index.server.html': {size: 1017, hash: 'f6fcb7c86d25422dd5e573d30dfd956fbe6122b9d5cdcc0a2add3130c610fea9', text: () => import('./assets-chunks/index_server_html.mjs').then(m => m.default)},
    'news-settings/index.html': {size: 17234, hash: '41dff852c01736742a4fea2a2026f41b41db7774bd4ba6c3be79dc6f8fb42ede', text: () => import('./assets-chunks/news-settings_index_html.mjs').then(m => m.default)},
    'news/index.html': {size: 20097, hash: '1d24fec56228946f8a9c2d00e0f1435f9dffa3c53eb5e8e1b2d796ff3f8972a0', text: () => import('./assets-chunks/news_index_html.mjs').then(m => m.default)},
    'admin/index.html': {size: 16302, hash: '42c16375e34064b58446148efb564074933162f1841a8e1783f711341be47095', text: () => import('./assets-chunks/admin_index_html.mjs').then(m => m.default)},
    'styles-5INURTSO.css': {size: 0, hash: 'menYUTfbRu8', text: () => import('./assets-chunks/styles-5INURTSO_css.mjs').then(m => m.default)}
  },
};
