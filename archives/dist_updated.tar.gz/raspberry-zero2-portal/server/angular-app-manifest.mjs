
export default {
  bootstrap: () => import('./main.server.mjs').then(m => m.default),
  inlineCriticalCss: true,
  baseHref: '/',
  locale: undefined,
  routes: [
  {
    "renderMode": 2,
    "route": "/news"
  },
  {
    "renderMode": 2,
    "route": "/news-settings"
  }
],
  entryPointToBrowserMapping: undefined,
  assets: {
    'index.csr.html': {size: 504, hash: 'd31bdbe5ac3f915ec71c129998f2925f62d1cf6176ca335f31839e6d8f0f0f5b', text: () => import('./assets-chunks/index_csr_html.mjs').then(m => m.default)},
    'index.server.html': {size: 1017, hash: 'e92dfcfefbcefab50329cd38f9f9b34016791438f77735375f1c574ee53469e2', text: () => import('./assets-chunks/index_server_html.mjs').then(m => m.default)},
    'news/index.html': {size: 19573, hash: '04901a7d89dce2ec732f32d30c82410a9ad34d4724d9d39efd386b159609343c', text: () => import('./assets-chunks/news_index_html.mjs').then(m => m.default)},
    'news-settings/index.html': {size: 17351, hash: 'c491ba00a29e9608b2af943147fc534d9f4979bc190d5cf7d90b75eb3564de40', text: () => import('./assets-chunks/news-settings_index_html.mjs').then(m => m.default)},
    'styles-5INURTSO.css': {size: 0, hash: 'menYUTfbRu8', text: () => import('./assets-chunks/styles-5INURTSO_css.mjs').then(m => m.default)}
  },
};
