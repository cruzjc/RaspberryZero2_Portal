// Original file: null


export interface UInt32Value {
  'value'?: (number);
}

export interface UInt32Value__Output {
  'value': (number);
}
