# Inworld AI Node.js SDK

The **Inworld AI Node.js SDK** enables Developers to easily integrate AI characters into your Node.js environment. 

Please visit our [Node.js Documentation](https://docs.inworld.ai/docs/tutorial-integrations/node/) page for more details.

Please create an account [here](https://studio.inworld.ai/signup) if you haven't already before getting started.
This tutorial series will begin with an overview of compatibility, assets, and API references.
