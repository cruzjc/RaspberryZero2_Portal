// src/server.ts
import express from "express";
import { dirname, resolve, join as join2 } from "node:path";
import { fileURLToPath } from "node:url";
import { existsSync as existsSync2, readFileSync as readFileSync2, writeFileSync as writeFileSync2 } from "fs";
import { execSync } from "child_process";
import os from "os";

// node_modules/@google/generative-ai/dist/index.mjs
var SchemaType;
(function(SchemaType2) {
  SchemaType2["STRING"] = "string";
  SchemaType2["NUMBER"] = "number";
  SchemaType2["INTEGER"] = "integer";
  SchemaType2["BOOLEAN"] = "boolean";
  SchemaType2["ARRAY"] = "array";
  SchemaType2["OBJECT"] = "object";
})(SchemaType || (SchemaType = {}));
var ExecutableCodeLanguage;
(function(ExecutableCodeLanguage2) {
  ExecutableCodeLanguage2["LANGUAGE_UNSPECIFIED"] = "language_unspecified";
  ExecutableCodeLanguage2["PYTHON"] = "python";
})(ExecutableCodeLanguage || (ExecutableCodeLanguage = {}));
var Outcome;
(function(Outcome2) {
  Outcome2["OUTCOME_UNSPECIFIED"] = "outcome_unspecified";
  Outcome2["OUTCOME_OK"] = "outcome_ok";
  Outcome2["OUTCOME_FAILED"] = "outcome_failed";
  Outcome2["OUTCOME_DEADLINE_EXCEEDED"] = "outcome_deadline_exceeded";
})(Outcome || (Outcome = {}));
var POSSIBLE_ROLES = ["user", "model", "function", "system"];
var HarmCategory;
(function(HarmCategory2) {
  HarmCategory2["HARM_CATEGORY_UNSPECIFIED"] = "HARM_CATEGORY_UNSPECIFIED";
  HarmCategory2["HARM_CATEGORY_HATE_SPEECH"] = "HARM_CATEGORY_HATE_SPEECH";
  HarmCategory2["HARM_CATEGORY_SEXUALLY_EXPLICIT"] = "HARM_CATEGORY_SEXUALLY_EXPLICIT";
  HarmCategory2["HARM_CATEGORY_HARASSMENT"] = "HARM_CATEGORY_HARASSMENT";
  HarmCategory2["HARM_CATEGORY_DANGEROUS_CONTENT"] = "HARM_CATEGORY_DANGEROUS_CONTENT";
  HarmCategory2["HARM_CATEGORY_CIVIC_INTEGRITY"] = "HARM_CATEGORY_CIVIC_INTEGRITY";
})(HarmCategory || (HarmCategory = {}));
var HarmBlockThreshold;
(function(HarmBlockThreshold2) {
  HarmBlockThreshold2["HARM_BLOCK_THRESHOLD_UNSPECIFIED"] = "HARM_BLOCK_THRESHOLD_UNSPECIFIED";
  HarmBlockThreshold2["BLOCK_LOW_AND_ABOVE"] = "BLOCK_LOW_AND_ABOVE";
  HarmBlockThreshold2["BLOCK_MEDIUM_AND_ABOVE"] = "BLOCK_MEDIUM_AND_ABOVE";
  HarmBlockThreshold2["BLOCK_ONLY_HIGH"] = "BLOCK_ONLY_HIGH";
  HarmBlockThreshold2["BLOCK_NONE"] = "BLOCK_NONE";
})(HarmBlockThreshold || (HarmBlockThreshold = {}));
var HarmProbability;
(function(HarmProbability2) {
  HarmProbability2["HARM_PROBABILITY_UNSPECIFIED"] = "HARM_PROBABILITY_UNSPECIFIED";
  HarmProbability2["NEGLIGIBLE"] = "NEGLIGIBLE";
  HarmProbability2["LOW"] = "LOW";
  HarmProbability2["MEDIUM"] = "MEDIUM";
  HarmProbability2["HIGH"] = "HIGH";
})(HarmProbability || (HarmProbability = {}));
var BlockReason;
(function(BlockReason2) {
  BlockReason2["BLOCKED_REASON_UNSPECIFIED"] = "BLOCKED_REASON_UNSPECIFIED";
  BlockReason2["SAFETY"] = "SAFETY";
  BlockReason2["OTHER"] = "OTHER";
})(BlockReason || (BlockReason = {}));
var FinishReason;
(function(FinishReason2) {
  FinishReason2["FINISH_REASON_UNSPECIFIED"] = "FINISH_REASON_UNSPECIFIED";
  FinishReason2["STOP"] = "STOP";
  FinishReason2["MAX_TOKENS"] = "MAX_TOKENS";
  FinishReason2["SAFETY"] = "SAFETY";
  FinishReason2["RECITATION"] = "RECITATION";
  FinishReason2["LANGUAGE"] = "LANGUAGE";
  FinishReason2["BLOCKLIST"] = "BLOCKLIST";
  FinishReason2["PROHIBITED_CONTENT"] = "PROHIBITED_CONTENT";
  FinishReason2["SPII"] = "SPII";
  FinishReason2["MALFORMED_FUNCTION_CALL"] = "MALFORMED_FUNCTION_CALL";
  FinishReason2["OTHER"] = "OTHER";
})(FinishReason || (FinishReason = {}));
var TaskType;
(function(TaskType2) {
  TaskType2["TASK_TYPE_UNSPECIFIED"] = "TASK_TYPE_UNSPECIFIED";
  TaskType2["RETRIEVAL_QUERY"] = "RETRIEVAL_QUERY";
  TaskType2["RETRIEVAL_DOCUMENT"] = "RETRIEVAL_DOCUMENT";
  TaskType2["SEMANTIC_SIMILARITY"] = "SEMANTIC_SIMILARITY";
  TaskType2["CLASSIFICATION"] = "CLASSIFICATION";
  TaskType2["CLUSTERING"] = "CLUSTERING";
})(TaskType || (TaskType = {}));
var FunctionCallingMode;
(function(FunctionCallingMode2) {
  FunctionCallingMode2["MODE_UNSPECIFIED"] = "MODE_UNSPECIFIED";
  FunctionCallingMode2["AUTO"] = "AUTO";
  FunctionCallingMode2["ANY"] = "ANY";
  FunctionCallingMode2["NONE"] = "NONE";
})(FunctionCallingMode || (FunctionCallingMode = {}));
var DynamicRetrievalMode;
(function(DynamicRetrievalMode2) {
  DynamicRetrievalMode2["MODE_UNSPECIFIED"] = "MODE_UNSPECIFIED";
  DynamicRetrievalMode2["MODE_DYNAMIC"] = "MODE_DYNAMIC";
})(DynamicRetrievalMode || (DynamicRetrievalMode = {}));
var GoogleGenerativeAIError = class extends Error {
  constructor(message) {
    super(`[GoogleGenerativeAI Error]: ${message}`);
  }
};
var GoogleGenerativeAIResponseError = class extends GoogleGenerativeAIError {
  constructor(message, response) {
    super(message);
    this.response = response;
  }
};
var GoogleGenerativeAIFetchError = class extends GoogleGenerativeAIError {
  constructor(message, status, statusText, errorDetails) {
    super(message);
    this.status = status;
    this.statusText = statusText;
    this.errorDetails = errorDetails;
  }
};
var GoogleGenerativeAIRequestInputError = class extends GoogleGenerativeAIError {
};
var GoogleGenerativeAIAbortError = class extends GoogleGenerativeAIError {
};
var DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com";
var DEFAULT_API_VERSION = "v1beta";
var PACKAGE_VERSION = "0.24.1";
var PACKAGE_LOG_HEADER = "genai-js";
var Task;
(function(Task2) {
  Task2["GENERATE_CONTENT"] = "generateContent";
  Task2["STREAM_GENERATE_CONTENT"] = "streamGenerateContent";
  Task2["COUNT_TOKENS"] = "countTokens";
  Task2["EMBED_CONTENT"] = "embedContent";
  Task2["BATCH_EMBED_CONTENTS"] = "batchEmbedContents";
})(Task || (Task = {}));
var RequestUrl = class {
  constructor(model, task, apiKey, stream, requestOptions) {
    this.model = model;
    this.task = task;
    this.apiKey = apiKey;
    this.stream = stream;
    this.requestOptions = requestOptions;
  }
  toString() {
    var _a, _b;
    const apiVersion = ((_a = this.requestOptions) === null || _a === void 0 ? void 0 : _a.apiVersion) || DEFAULT_API_VERSION;
    const baseUrl = ((_b = this.requestOptions) === null || _b === void 0 ? void 0 : _b.baseUrl) || DEFAULT_BASE_URL;
    let url = `${baseUrl}/${apiVersion}/${this.model}:${this.task}`;
    if (this.stream) {
      url += "?alt=sse";
    }
    return url;
  }
};
function getClientHeaders(requestOptions) {
  const clientHeaders = [];
  if (requestOptions === null || requestOptions === void 0 ? void 0 : requestOptions.apiClient) {
    clientHeaders.push(requestOptions.apiClient);
  }
  clientHeaders.push(`${PACKAGE_LOG_HEADER}/${PACKAGE_VERSION}`);
  return clientHeaders.join(" ");
}
async function getHeaders(url) {
  var _a;
  const headers = new Headers();
  headers.append("Content-Type", "application/json");
  headers.append("x-goog-api-client", getClientHeaders(url.requestOptions));
  headers.append("x-goog-api-key", url.apiKey);
  let customHeaders = (_a = url.requestOptions) === null || _a === void 0 ? void 0 : _a.customHeaders;
  if (customHeaders) {
    if (!(customHeaders instanceof Headers)) {
      try {
        customHeaders = new Headers(customHeaders);
      } catch (e) {
        throw new GoogleGenerativeAIRequestInputError(`unable to convert customHeaders value ${JSON.stringify(customHeaders)} to Headers: ${e.message}`);
      }
    }
    for (const [headerName, headerValue] of customHeaders.entries()) {
      if (headerName === "x-goog-api-key") {
        throw new GoogleGenerativeAIRequestInputError(`Cannot set reserved header name ${headerName}`);
      } else if (headerName === "x-goog-api-client") {
        throw new GoogleGenerativeAIRequestInputError(`Header name ${headerName} can only be set using the apiClient field`);
      }
      headers.append(headerName, headerValue);
    }
  }
  return headers;
}
async function constructModelRequest(model, task, apiKey, stream, body, requestOptions) {
  const url = new RequestUrl(model, task, apiKey, stream, requestOptions);
  return {
    url: url.toString(),
    fetchOptions: Object.assign(Object.assign({}, buildFetchOptions(requestOptions)), { method: "POST", headers: await getHeaders(url), body })
  };
}
async function makeModelRequest(model, task, apiKey, stream, body, requestOptions = {}, fetchFn = fetch) {
  const { url, fetchOptions } = await constructModelRequest(model, task, apiKey, stream, body, requestOptions);
  return makeRequest(url, fetchOptions, fetchFn);
}
async function makeRequest(url, fetchOptions, fetchFn = fetch) {
  let response;
  try {
    response = await fetchFn(url, fetchOptions);
  } catch (e) {
    handleResponseError(e, url);
  }
  if (!response.ok) {
    await handleResponseNotOk(response, url);
  }
  return response;
}
function handleResponseError(e, url) {
  let err = e;
  if (err.name === "AbortError") {
    err = new GoogleGenerativeAIAbortError(`Request aborted when fetching ${url.toString()}: ${e.message}`);
    err.stack = e.stack;
  } else if (!(e instanceof GoogleGenerativeAIFetchError || e instanceof GoogleGenerativeAIRequestInputError)) {
    err = new GoogleGenerativeAIError(`Error fetching from ${url.toString()}: ${e.message}`);
    err.stack = e.stack;
  }
  throw err;
}
async function handleResponseNotOk(response, url) {
  let message = "";
  let errorDetails;
  try {
    const json = await response.json();
    message = json.error.message;
    if (json.error.details) {
      message += ` ${JSON.stringify(json.error.details)}`;
      errorDetails = json.error.details;
    }
  } catch (e) {
  }
  throw new GoogleGenerativeAIFetchError(`Error fetching from ${url.toString()}: [${response.status} ${response.statusText}] ${message}`, response.status, response.statusText, errorDetails);
}
function buildFetchOptions(requestOptions) {
  const fetchOptions = {};
  if ((requestOptions === null || requestOptions === void 0 ? void 0 : requestOptions.signal) !== void 0 || (requestOptions === null || requestOptions === void 0 ? void 0 : requestOptions.timeout) >= 0) {
    const controller = new AbortController();
    if ((requestOptions === null || requestOptions === void 0 ? void 0 : requestOptions.timeout) >= 0) {
      setTimeout(() => controller.abort(), requestOptions.timeout);
    }
    if (requestOptions === null || requestOptions === void 0 ? void 0 : requestOptions.signal) {
      requestOptions.signal.addEventListener("abort", () => {
        controller.abort();
      });
    }
    fetchOptions.signal = controller.signal;
  }
  return fetchOptions;
}
function addHelpers(response) {
  response.text = () => {
    if (response.candidates && response.candidates.length > 0) {
      if (response.candidates.length > 1) {
        console.warn(`This response had ${response.candidates.length} candidates. Returning text from the first candidate only. Access response.candidates directly to use the other candidates.`);
      }
      if (hadBadFinishReason(response.candidates[0])) {
        throw new GoogleGenerativeAIResponseError(`${formatBlockErrorMessage(response)}`, response);
      }
      return getText(response);
    } else if (response.promptFeedback) {
      throw new GoogleGenerativeAIResponseError(`Text not available. ${formatBlockErrorMessage(response)}`, response);
    }
    return "";
  };
  response.functionCall = () => {
    if (response.candidates && response.candidates.length > 0) {
      if (response.candidates.length > 1) {
        console.warn(`This response had ${response.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`);
      }
      if (hadBadFinishReason(response.candidates[0])) {
        throw new GoogleGenerativeAIResponseError(`${formatBlockErrorMessage(response)}`, response);
      }
      console.warn(`response.functionCall() is deprecated. Use response.functionCalls() instead.`);
      return getFunctionCalls(response)[0];
    } else if (response.promptFeedback) {
      throw new GoogleGenerativeAIResponseError(`Function call not available. ${formatBlockErrorMessage(response)}`, response);
    }
    return void 0;
  };
  response.functionCalls = () => {
    if (response.candidates && response.candidates.length > 0) {
      if (response.candidates.length > 1) {
        console.warn(`This response had ${response.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`);
      }
      if (hadBadFinishReason(response.candidates[0])) {
        throw new GoogleGenerativeAIResponseError(`${formatBlockErrorMessage(response)}`, response);
      }
      return getFunctionCalls(response);
    } else if (response.promptFeedback) {
      throw new GoogleGenerativeAIResponseError(`Function call not available. ${formatBlockErrorMessage(response)}`, response);
    }
    return void 0;
  };
  return response;
}
function getText(response) {
  var _a, _b, _c, _d;
  const textStrings = [];
  if ((_b = (_a = response.candidates) === null || _a === void 0 ? void 0 : _a[0].content) === null || _b === void 0 ? void 0 : _b.parts) {
    for (const part of (_d = (_c = response.candidates) === null || _c === void 0 ? void 0 : _c[0].content) === null || _d === void 0 ? void 0 : _d.parts) {
      if (part.text) {
        textStrings.push(part.text);
      }
      if (part.executableCode) {
        textStrings.push("\n```" + part.executableCode.language + "\n" + part.executableCode.code + "\n```\n");
      }
      if (part.codeExecutionResult) {
        textStrings.push("\n```\n" + part.codeExecutionResult.output + "\n```\n");
      }
    }
  }
  if (textStrings.length > 0) {
    return textStrings.join("");
  } else {
    return "";
  }
}
function getFunctionCalls(response) {
  var _a, _b, _c, _d;
  const functionCalls = [];
  if ((_b = (_a = response.candidates) === null || _a === void 0 ? void 0 : _a[0].content) === null || _b === void 0 ? void 0 : _b.parts) {
    for (const part of (_d = (_c = response.candidates) === null || _c === void 0 ? void 0 : _c[0].content) === null || _d === void 0 ? void 0 : _d.parts) {
      if (part.functionCall) {
        functionCalls.push(part.functionCall);
      }
    }
  }
  if (functionCalls.length > 0) {
    return functionCalls;
  } else {
    return void 0;
  }
}
var badFinishReasons = [
  FinishReason.RECITATION,
  FinishReason.SAFETY,
  FinishReason.LANGUAGE
];
function hadBadFinishReason(candidate) {
  return !!candidate.finishReason && badFinishReasons.includes(candidate.finishReason);
}
function formatBlockErrorMessage(response) {
  var _a, _b, _c;
  let message = "";
  if ((!response.candidates || response.candidates.length === 0) && response.promptFeedback) {
    message += "Response was blocked";
    if ((_a = response.promptFeedback) === null || _a === void 0 ? void 0 : _a.blockReason) {
      message += ` due to ${response.promptFeedback.blockReason}`;
    }
    if ((_b = response.promptFeedback) === null || _b === void 0 ? void 0 : _b.blockReasonMessage) {
      message += `: ${response.promptFeedback.blockReasonMessage}`;
    }
  } else if ((_c = response.candidates) === null || _c === void 0 ? void 0 : _c[0]) {
    const firstCandidate = response.candidates[0];
    if (hadBadFinishReason(firstCandidate)) {
      message += `Candidate was blocked due to ${firstCandidate.finishReason}`;
      if (firstCandidate.finishMessage) {
        message += `: ${firstCandidate.finishMessage}`;
      }
    }
  }
  return message;
}
function __await(v) {
  return this instanceof __await ? (this.v = v, this) : new __await(v);
}
function __asyncGenerator(thisArg, _arguments, generator) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var g = generator.apply(thisArg, _arguments || []), i, q = [];
  return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
    return this;
  }, i;
  function verb(n) {
    if (g[n]) i[n] = function(v) {
      return new Promise(function(a, b) {
        q.push([n, v, a, b]) > 1 || resume(n, v);
      });
    };
  }
  function resume(n, v) {
    try {
      step(g[n](v));
    } catch (e) {
      settle(q[0][3], e);
    }
  }
  function step(r) {
    r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
  }
  function fulfill(value) {
    resume("next", value);
  }
  function reject(value) {
    resume("throw", value);
  }
  function settle(f, v) {
    if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
  }
}
var responseLineRE = /^data\: (.*)(?:\n\n|\r\r|\r\n\r\n)/;
function processStream(response) {
  const inputStream = response.body.pipeThrough(new TextDecoderStream("utf8", { fatal: true }));
  const responseStream = getResponseStream(inputStream);
  const [stream1, stream2] = responseStream.tee();
  return {
    stream: generateResponseSequence(stream1),
    response: getResponsePromise(stream2)
  };
}
async function getResponsePromise(stream) {
  const allResponses = [];
  const reader = stream.getReader();
  while (true) {
    const { done, value } = await reader.read();
    if (done) {
      return addHelpers(aggregateResponses(allResponses));
    }
    allResponses.push(value);
  }
}
function generateResponseSequence(stream) {
  return __asyncGenerator(this, arguments, function* generateResponseSequence_1() {
    const reader = stream.getReader();
    while (true) {
      const { value, done } = yield __await(reader.read());
      if (done) {
        break;
      }
      yield yield __await(addHelpers(value));
    }
  });
}
function getResponseStream(inputStream) {
  const reader = inputStream.getReader();
  const stream = new ReadableStream({
    start(controller) {
      let currentText = "";
      return pump();
      function pump() {
        return reader.read().then(({ value, done }) => {
          if (done) {
            if (currentText.trim()) {
              controller.error(new GoogleGenerativeAIError("Failed to parse stream"));
              return;
            }
            controller.close();
            return;
          }
          currentText += value;
          let match = currentText.match(responseLineRE);
          let parsedResponse;
          while (match) {
            try {
              parsedResponse = JSON.parse(match[1]);
            } catch (e) {
              controller.error(new GoogleGenerativeAIError(`Error parsing JSON response: "${match[1]}"`));
              return;
            }
            controller.enqueue(parsedResponse);
            currentText = currentText.substring(match[0].length);
            match = currentText.match(responseLineRE);
          }
          return pump();
        }).catch((e) => {
          let err = e;
          err.stack = e.stack;
          if (err.name === "AbortError") {
            err = new GoogleGenerativeAIAbortError("Request aborted when reading from the stream");
          } else {
            err = new GoogleGenerativeAIError("Error reading from the stream");
          }
          throw err;
        });
      }
    }
  });
  return stream;
}
function aggregateResponses(responses) {
  const lastResponse = responses[responses.length - 1];
  const aggregatedResponse = {
    promptFeedback: lastResponse === null || lastResponse === void 0 ? void 0 : lastResponse.promptFeedback
  };
  for (const response of responses) {
    if (response.candidates) {
      let candidateIndex = 0;
      for (const candidate of response.candidates) {
        if (!aggregatedResponse.candidates) {
          aggregatedResponse.candidates = [];
        }
        if (!aggregatedResponse.candidates[candidateIndex]) {
          aggregatedResponse.candidates[candidateIndex] = {
            index: candidateIndex
          };
        }
        aggregatedResponse.candidates[candidateIndex].citationMetadata = candidate.citationMetadata;
        aggregatedResponse.candidates[candidateIndex].groundingMetadata = candidate.groundingMetadata;
        aggregatedResponse.candidates[candidateIndex].finishReason = candidate.finishReason;
        aggregatedResponse.candidates[candidateIndex].finishMessage = candidate.finishMessage;
        aggregatedResponse.candidates[candidateIndex].safetyRatings = candidate.safetyRatings;
        if (candidate.content && candidate.content.parts) {
          if (!aggregatedResponse.candidates[candidateIndex].content) {
            aggregatedResponse.candidates[candidateIndex].content = {
              role: candidate.content.role || "user",
              parts: []
            };
          }
          const newPart = {};
          for (const part of candidate.content.parts) {
            if (part.text) {
              newPart.text = part.text;
            }
            if (part.functionCall) {
              newPart.functionCall = part.functionCall;
            }
            if (part.executableCode) {
              newPart.executableCode = part.executableCode;
            }
            if (part.codeExecutionResult) {
              newPart.codeExecutionResult = part.codeExecutionResult;
            }
            if (Object.keys(newPart).length === 0) {
              newPart.text = "";
            }
            aggregatedResponse.candidates[candidateIndex].content.parts.push(newPart);
          }
        }
      }
      candidateIndex++;
    }
    if (response.usageMetadata) {
      aggregatedResponse.usageMetadata = response.usageMetadata;
    }
  }
  return aggregatedResponse;
}
async function generateContentStream(apiKey, model, params, requestOptions) {
  const response = await makeModelRequest(
    model,
    Task.STREAM_GENERATE_CONTENT,
    apiKey,
    /* stream */
    true,
    JSON.stringify(params),
    requestOptions
  );
  return processStream(response);
}
async function generateContent(apiKey, model, params, requestOptions) {
  const response = await makeModelRequest(
    model,
    Task.GENERATE_CONTENT,
    apiKey,
    /* stream */
    false,
    JSON.stringify(params),
    requestOptions
  );
  const responseJson = await response.json();
  const enhancedResponse = addHelpers(responseJson);
  return {
    response: enhancedResponse
  };
}
function formatSystemInstruction(input) {
  if (input == null) {
    return void 0;
  } else if (typeof input === "string") {
    return { role: "system", parts: [{ text: input }] };
  } else if (input.text) {
    return { role: "system", parts: [input] };
  } else if (input.parts) {
    if (!input.role) {
      return { role: "system", parts: input.parts };
    } else {
      return input;
    }
  }
}
function formatNewContent(request) {
  let newParts = [];
  if (typeof request === "string") {
    newParts = [{ text: request }];
  } else {
    for (const partOrString of request) {
      if (typeof partOrString === "string") {
        newParts.push({ text: partOrString });
      } else {
        newParts.push(partOrString);
      }
    }
  }
  return assignRoleToPartsAndValidateSendMessageRequest(newParts);
}
function assignRoleToPartsAndValidateSendMessageRequest(parts) {
  const userContent = { role: "user", parts: [] };
  const functionContent = { role: "function", parts: [] };
  let hasUserContent = false;
  let hasFunctionContent = false;
  for (const part of parts) {
    if ("functionResponse" in part) {
      functionContent.parts.push(part);
      hasFunctionContent = true;
    } else {
      userContent.parts.push(part);
      hasUserContent = true;
    }
  }
  if (hasUserContent && hasFunctionContent) {
    throw new GoogleGenerativeAIError("Within a single message, FunctionResponse cannot be mixed with other type of part in the request for sending chat message.");
  }
  if (!hasUserContent && !hasFunctionContent) {
    throw new GoogleGenerativeAIError("No content is provided for sending chat message.");
  }
  if (hasUserContent) {
    return userContent;
  }
  return functionContent;
}
function formatCountTokensInput(params, modelParams) {
  var _a;
  let formattedGenerateContentRequest = {
    model: modelParams === null || modelParams === void 0 ? void 0 : modelParams.model,
    generationConfig: modelParams === null || modelParams === void 0 ? void 0 : modelParams.generationConfig,
    safetySettings: modelParams === null || modelParams === void 0 ? void 0 : modelParams.safetySettings,
    tools: modelParams === null || modelParams === void 0 ? void 0 : modelParams.tools,
    toolConfig: modelParams === null || modelParams === void 0 ? void 0 : modelParams.toolConfig,
    systemInstruction: modelParams === null || modelParams === void 0 ? void 0 : modelParams.systemInstruction,
    cachedContent: (_a = modelParams === null || modelParams === void 0 ? void 0 : modelParams.cachedContent) === null || _a === void 0 ? void 0 : _a.name,
    contents: []
  };
  const containsGenerateContentRequest = params.generateContentRequest != null;
  if (params.contents) {
    if (containsGenerateContentRequest) {
      throw new GoogleGenerativeAIRequestInputError("CountTokensRequest must have one of contents or generateContentRequest, not both.");
    }
    formattedGenerateContentRequest.contents = params.contents;
  } else if (containsGenerateContentRequest) {
    formattedGenerateContentRequest = Object.assign(Object.assign({}, formattedGenerateContentRequest), params.generateContentRequest);
  } else {
    const content = formatNewContent(params);
    formattedGenerateContentRequest.contents = [content];
  }
  return { generateContentRequest: formattedGenerateContentRequest };
}
function formatGenerateContentInput(params) {
  let formattedRequest;
  if (params.contents) {
    formattedRequest = params;
  } else {
    const content = formatNewContent(params);
    formattedRequest = { contents: [content] };
  }
  if (params.systemInstruction) {
    formattedRequest.systemInstruction = formatSystemInstruction(params.systemInstruction);
  }
  return formattedRequest;
}
function formatEmbedContentInput(params) {
  if (typeof params === "string" || Array.isArray(params)) {
    const content = formatNewContent(params);
    return { content };
  }
  return params;
}
var VALID_PART_FIELDS = [
  "text",
  "inlineData",
  "functionCall",
  "functionResponse",
  "executableCode",
  "codeExecutionResult"
];
var VALID_PARTS_PER_ROLE = {
  user: ["text", "inlineData"],
  function: ["functionResponse"],
  model: ["text", "functionCall", "executableCode", "codeExecutionResult"],
  // System instructions shouldn't be in history anyway.
  system: ["text"]
};
function validateChatHistory(history) {
  let prevContent = false;
  for (const currContent of history) {
    const { role, parts } = currContent;
    if (!prevContent && role !== "user") {
      throw new GoogleGenerativeAIError(`First content should be with role 'user', got ${role}`);
    }
    if (!POSSIBLE_ROLES.includes(role)) {
      throw new GoogleGenerativeAIError(`Each item should include role field. Got ${role} but valid roles are: ${JSON.stringify(POSSIBLE_ROLES)}`);
    }
    if (!Array.isArray(parts)) {
      throw new GoogleGenerativeAIError("Content should have 'parts' property with an array of Parts");
    }
    if (parts.length === 0) {
      throw new GoogleGenerativeAIError("Each Content should have at least one part");
    }
    const countFields = {
      text: 0,
      inlineData: 0,
      functionCall: 0,
      functionResponse: 0,
      fileData: 0,
      executableCode: 0,
      codeExecutionResult: 0
    };
    for (const part of parts) {
      for (const key of VALID_PART_FIELDS) {
        if (key in part) {
          countFields[key] += 1;
        }
      }
    }
    const validParts = VALID_PARTS_PER_ROLE[role];
    for (const key of VALID_PART_FIELDS) {
      if (!validParts.includes(key) && countFields[key] > 0) {
        throw new GoogleGenerativeAIError(`Content with role '${role}' can't contain '${key}' part`);
      }
    }
    prevContent = true;
  }
}
function isValidResponse(response) {
  var _a;
  if (response.candidates === void 0 || response.candidates.length === 0) {
    return false;
  }
  const content = (_a = response.candidates[0]) === null || _a === void 0 ? void 0 : _a.content;
  if (content === void 0) {
    return false;
  }
  if (content.parts === void 0 || content.parts.length === 0) {
    return false;
  }
  for (const part of content.parts) {
    if (part === void 0 || Object.keys(part).length === 0) {
      return false;
    }
    if (part.text !== void 0 && part.text === "") {
      return false;
    }
  }
  return true;
}
var SILENT_ERROR = "SILENT_ERROR";
var ChatSession = class {
  constructor(apiKey, model, params, _requestOptions = {}) {
    this.model = model;
    this.params = params;
    this._requestOptions = _requestOptions;
    this._history = [];
    this._sendPromise = Promise.resolve();
    this._apiKey = apiKey;
    if (params === null || params === void 0 ? void 0 : params.history) {
      validateChatHistory(params.history);
      this._history = params.history;
    }
  }
  /**
   * Gets the chat history so far. Blocked prompts are not added to history.
   * Blocked candidates are not added to history, nor are the prompts that
   * generated them.
   */
  async getHistory() {
    await this._sendPromise;
    return this._history;
  }
  /**
   * Sends a chat message and receives a non-streaming
   * {@link GenerateContentResult}.
   *
   * Fields set in the optional {@link SingleRequestOptions} parameter will
   * take precedence over the {@link RequestOptions} values provided to
   * {@link GoogleGenerativeAI.getGenerativeModel }.
   */
  async sendMessage(request, requestOptions = {}) {
    var _a, _b, _c, _d, _e, _f;
    await this._sendPromise;
    const newContent = formatNewContent(request);
    const generateContentRequest = {
      safetySettings: (_a = this.params) === null || _a === void 0 ? void 0 : _a.safetySettings,
      generationConfig: (_b = this.params) === null || _b === void 0 ? void 0 : _b.generationConfig,
      tools: (_c = this.params) === null || _c === void 0 ? void 0 : _c.tools,
      toolConfig: (_d = this.params) === null || _d === void 0 ? void 0 : _d.toolConfig,
      systemInstruction: (_e = this.params) === null || _e === void 0 ? void 0 : _e.systemInstruction,
      cachedContent: (_f = this.params) === null || _f === void 0 ? void 0 : _f.cachedContent,
      contents: [...this._history, newContent]
    };
    const chatSessionRequestOptions = Object.assign(Object.assign({}, this._requestOptions), requestOptions);
    let finalResult;
    this._sendPromise = this._sendPromise.then(() => generateContent(this._apiKey, this.model, generateContentRequest, chatSessionRequestOptions)).then((result) => {
      var _a2;
      if (isValidResponse(result.response)) {
        this._history.push(newContent);
        const responseContent = Object.assign({
          parts: [],
          // Response seems to come back without a role set.
          role: "model"
        }, (_a2 = result.response.candidates) === null || _a2 === void 0 ? void 0 : _a2[0].content);
        this._history.push(responseContent);
      } else {
        const blockErrorMessage = formatBlockErrorMessage(result.response);
        if (blockErrorMessage) {
          console.warn(`sendMessage() was unsuccessful. ${blockErrorMessage}. Inspect response object for details.`);
        }
      }
      finalResult = result;
    }).catch((e) => {
      this._sendPromise = Promise.resolve();
      throw e;
    });
    await this._sendPromise;
    return finalResult;
  }
  /**
   * Sends a chat message and receives the response as a
   * {@link GenerateContentStreamResult} containing an iterable stream
   * and a response promise.
   *
   * Fields set in the optional {@link SingleRequestOptions} parameter will
   * take precedence over the {@link RequestOptions} values provided to
   * {@link GoogleGenerativeAI.getGenerativeModel }.
   */
  async sendMessageStream(request, requestOptions = {}) {
    var _a, _b, _c, _d, _e, _f;
    await this._sendPromise;
    const newContent = formatNewContent(request);
    const generateContentRequest = {
      safetySettings: (_a = this.params) === null || _a === void 0 ? void 0 : _a.safetySettings,
      generationConfig: (_b = this.params) === null || _b === void 0 ? void 0 : _b.generationConfig,
      tools: (_c = this.params) === null || _c === void 0 ? void 0 : _c.tools,
      toolConfig: (_d = this.params) === null || _d === void 0 ? void 0 : _d.toolConfig,
      systemInstruction: (_e = this.params) === null || _e === void 0 ? void 0 : _e.systemInstruction,
      cachedContent: (_f = this.params) === null || _f === void 0 ? void 0 : _f.cachedContent,
      contents: [...this._history, newContent]
    };
    const chatSessionRequestOptions = Object.assign(Object.assign({}, this._requestOptions), requestOptions);
    const streamPromise = generateContentStream(this._apiKey, this.model, generateContentRequest, chatSessionRequestOptions);
    this._sendPromise = this._sendPromise.then(() => streamPromise).catch((_ignored) => {
      throw new Error(SILENT_ERROR);
    }).then((streamResult) => streamResult.response).then((response) => {
      if (isValidResponse(response)) {
        this._history.push(newContent);
        const responseContent = Object.assign({}, response.candidates[0].content);
        if (!responseContent.role) {
          responseContent.role = "model";
        }
        this._history.push(responseContent);
      } else {
        const blockErrorMessage = formatBlockErrorMessage(response);
        if (blockErrorMessage) {
          console.warn(`sendMessageStream() was unsuccessful. ${blockErrorMessage}. Inspect response object for details.`);
        }
      }
    }).catch((e) => {
      if (e.message !== SILENT_ERROR) {
        console.error(e);
      }
    });
    return streamPromise;
  }
};
async function countTokens(apiKey, model, params, singleRequestOptions) {
  const response = await makeModelRequest(model, Task.COUNT_TOKENS, apiKey, false, JSON.stringify(params), singleRequestOptions);
  return response.json();
}
async function embedContent(apiKey, model, params, requestOptions) {
  const response = await makeModelRequest(model, Task.EMBED_CONTENT, apiKey, false, JSON.stringify(params), requestOptions);
  return response.json();
}
async function batchEmbedContents(apiKey, model, params, requestOptions) {
  const requestsWithModel = params.requests.map((request) => {
    return Object.assign(Object.assign({}, request), { model });
  });
  const response = await makeModelRequest(model, Task.BATCH_EMBED_CONTENTS, apiKey, false, JSON.stringify({ requests: requestsWithModel }), requestOptions);
  return response.json();
}
var GenerativeModel = class {
  constructor(apiKey, modelParams, _requestOptions = {}) {
    this.apiKey = apiKey;
    this._requestOptions = _requestOptions;
    if (modelParams.model.includes("/")) {
      this.model = modelParams.model;
    } else {
      this.model = `models/${modelParams.model}`;
    }
    this.generationConfig = modelParams.generationConfig || {};
    this.safetySettings = modelParams.safetySettings || [];
    this.tools = modelParams.tools;
    this.toolConfig = modelParams.toolConfig;
    this.systemInstruction = formatSystemInstruction(modelParams.systemInstruction);
    this.cachedContent = modelParams.cachedContent;
  }
  /**
   * Makes a single non-streaming call to the model
   * and returns an object containing a single {@link GenerateContentResponse}.
   *
   * Fields set in the optional {@link SingleRequestOptions} parameter will
   * take precedence over the {@link RequestOptions} values provided to
   * {@link GoogleGenerativeAI.getGenerativeModel }.
   */
  async generateContent(request, requestOptions = {}) {
    var _a;
    const formattedParams = formatGenerateContentInput(request);
    const generativeModelRequestOptions = Object.assign(Object.assign({}, this._requestOptions), requestOptions);
    return generateContent(this.apiKey, this.model, Object.assign({ generationConfig: this.generationConfig, safetySettings: this.safetySettings, tools: this.tools, toolConfig: this.toolConfig, systemInstruction: this.systemInstruction, cachedContent: (_a = this.cachedContent) === null || _a === void 0 ? void 0 : _a.name }, formattedParams), generativeModelRequestOptions);
  }
  /**
   * Makes a single streaming call to the model and returns an object
   * containing an iterable stream that iterates over all chunks in the
   * streaming response as well as a promise that returns the final
   * aggregated response.
   *
   * Fields set in the optional {@link SingleRequestOptions} parameter will
   * take precedence over the {@link RequestOptions} values provided to
   * {@link GoogleGenerativeAI.getGenerativeModel }.
   */
  async generateContentStream(request, requestOptions = {}) {
    var _a;
    const formattedParams = formatGenerateContentInput(request);
    const generativeModelRequestOptions = Object.assign(Object.assign({}, this._requestOptions), requestOptions);
    return generateContentStream(this.apiKey, this.model, Object.assign({ generationConfig: this.generationConfig, safetySettings: this.safetySettings, tools: this.tools, toolConfig: this.toolConfig, systemInstruction: this.systemInstruction, cachedContent: (_a = this.cachedContent) === null || _a === void 0 ? void 0 : _a.name }, formattedParams), generativeModelRequestOptions);
  }
  /**
   * Gets a new {@link ChatSession} instance which can be used for
   * multi-turn chats.
   */
  startChat(startChatParams) {
    var _a;
    return new ChatSession(this.apiKey, this.model, Object.assign({ generationConfig: this.generationConfig, safetySettings: this.safetySettings, tools: this.tools, toolConfig: this.toolConfig, systemInstruction: this.systemInstruction, cachedContent: (_a = this.cachedContent) === null || _a === void 0 ? void 0 : _a.name }, startChatParams), this._requestOptions);
  }
  /**
   * Counts the tokens in the provided request.
   *
   * Fields set in the optional {@link SingleRequestOptions} parameter will
   * take precedence over the {@link RequestOptions} values provided to
   * {@link GoogleGenerativeAI.getGenerativeModel }.
   */
  async countTokens(request, requestOptions = {}) {
    const formattedParams = formatCountTokensInput(request, {
      model: this.model,
      generationConfig: this.generationConfig,
      safetySettings: this.safetySettings,
      tools: this.tools,
      toolConfig: this.toolConfig,
      systemInstruction: this.systemInstruction,
      cachedContent: this.cachedContent
    });
    const generativeModelRequestOptions = Object.assign(Object.assign({}, this._requestOptions), requestOptions);
    return countTokens(this.apiKey, this.model, formattedParams, generativeModelRequestOptions);
  }
  /**
   * Embeds the provided content.
   *
   * Fields set in the optional {@link SingleRequestOptions} parameter will
   * take precedence over the {@link RequestOptions} values provided to
   * {@link GoogleGenerativeAI.getGenerativeModel }.
   */
  async embedContent(request, requestOptions = {}) {
    const formattedParams = formatEmbedContentInput(request);
    const generativeModelRequestOptions = Object.assign(Object.assign({}, this._requestOptions), requestOptions);
    return embedContent(this.apiKey, this.model, formattedParams, generativeModelRequestOptions);
  }
  /**
   * Embeds an array of {@link EmbedContentRequest}s.
   *
   * Fields set in the optional {@link SingleRequestOptions} parameter will
   * take precedence over the {@link RequestOptions} values provided to
   * {@link GoogleGenerativeAI.getGenerativeModel }.
   */
  async batchEmbedContents(batchEmbedContentRequest, requestOptions = {}) {
    const generativeModelRequestOptions = Object.assign(Object.assign({}, this._requestOptions), requestOptions);
    return batchEmbedContents(this.apiKey, this.model, batchEmbedContentRequest, generativeModelRequestOptions);
  }
};
var GoogleGenerativeAI = class {
  constructor(apiKey) {
    this.apiKey = apiKey;
  }
  /**
   * Gets a {@link GenerativeModel} instance for the provided model name.
   */
  getGenerativeModel(modelParams, requestOptions) {
    if (!modelParams.model) {
      throw new GoogleGenerativeAIError(`Must provide a model name. Example: genai.getGenerativeModel({ model: 'my-model-name' })`);
    }
    return new GenerativeModel(this.apiKey, modelParams, requestOptions);
  }
  /**
   * Creates a {@link GenerativeModel} instance from provided content cache.
   */
  getGenerativeModelFromCachedContent(cachedContent, modelParams, requestOptions) {
    if (!cachedContent.name) {
      throw new GoogleGenerativeAIRequestInputError("Cached content must contain a `name` field.");
    }
    if (!cachedContent.model) {
      throw new GoogleGenerativeAIRequestInputError("Cached content must contain a `model` field.");
    }
    const disallowedDuplicates = ["model", "systemInstruction"];
    for (const key of disallowedDuplicates) {
      if ((modelParams === null || modelParams === void 0 ? void 0 : modelParams[key]) && cachedContent[key] && (modelParams === null || modelParams === void 0 ? void 0 : modelParams[key]) !== cachedContent[key]) {
        if (key === "model") {
          const modelParamsComp = modelParams.model.startsWith("models/") ? modelParams.model.replace("models/", "") : modelParams.model;
          const cachedContentComp = cachedContent.model.startsWith("models/") ? cachedContent.model.replace("models/", "") : cachedContent.model;
          if (modelParamsComp === cachedContentComp) {
            continue;
          }
        }
        throw new GoogleGenerativeAIRequestInputError(`Different value for "${key}" specified in modelParams (${modelParams[key]}) and cachedContent (${cachedContent[key]})`);
      }
    }
    const modelParamsFromCache = Object.assign(Object.assign({}, modelParams), { model: cachedContent.model, tools: cachedContent.tools, toolConfig: cachedContent.toolConfig, systemInstruction: cachedContent.systemInstruction, cachedContent });
    return new GenerativeModel(this.apiKey, modelParamsFromCache, requestOptions);
  }
};

// src/news.ts
import { existsSync, readFileSync, writeFileSync, mkdirSync } from "fs";
import { join } from "path";
var HARDCODED_SOURCES = [
  // BREAKING NEWS (urgent/real-time feeds)
  { id: "BN1", name: "AP Breaking News", url: "https://apnews.com/rss/topnews", type: "news", category: "Breaking News", enabled: true },
  { id: "BN2", name: "Reuters Top News", url: "https://www.reutersagency.com/feed/?best-topics=top-news&post_type=best", type: "news", category: "Breaking News", enabled: true },
  { id: "BN3", name: "BBC Breaking", url: "https://feeds.bbci.co.uk/news/rss.xml", type: "news", category: "Breaking News", enabled: true },
  { id: "BN4", name: "NPR Breaking", url: "https://feeds.npr.org/1001/rss.xml", type: "news", category: "Breaking News", enabled: true },
  { id: "BN5", name: "Google News Top", url: "https://news.google.com/rss", type: "news", category: "Breaking News", enabled: true },
  // LOCAL (Hawaii-focused)
  { id: "L1", name: "Honolulu Star-Advertiser", url: "https://www.staradvertiser.com/feed/", type: "news", category: "Local", enabled: true },
  { id: "L2", name: "KITV", url: "https://www.kitv.com/feed/", type: "news", category: "Local", enabled: true },
  { id: "L3", name: "Hawaii News Now", url: "https://www.hawaiinewsnow.com/rss/", type: "news", category: "Local", enabled: true },
  { id: "L4", name: "Hawaii Public Radio", url: "https://www.hawaiipublicradio.org/rss/", type: "news", category: "Local", enabled: true },
  { id: "L5", name: "Maui Now", url: "https://mauinow.com/feed/", type: "news", category: "Local", enabled: true },
  { id: "L6", name: "Big Island Now", url: "https://bigislandnow.com/feed/", type: "news", category: "Local", enabled: true },
  { id: "L7", name: "West Hawaii Today", url: "https://www.westhawaiitoday.com/feed/", type: "news", category: "Local", enabled: true },
  { id: "L8", name: "KHON2", url: "https://www.khon2.com/feed/", type: "news", category: "Local", enabled: true },
  { id: "L9", name: "Civil Beat", url: "https://www.civilbeat.org/feed/", type: "news", category: "Local", enabled: true },
  { id: "L10", name: "Pacific Business News", url: "https://www.bizjournals.com/pacific/feed/rss", type: "news", category: "Local", enabled: true },
  // WORLD
  { id: "W1", name: "BBC World", url: "http://feeds.bbci.co.uk/news/world/rss.xml", type: "news", category: "World", enabled: true },
  { id: "W2", name: "Reuters World", url: "https://www.reutersagency.com/feed/?best-topics=world-news", type: "news", category: "World", enabled: true },
  { id: "W3", name: "Al Jazeera", url: "https://www.aljazeera.com/xml/rss/all.xml", type: "news", category: "World", enabled: true },
  { id: "W4", name: "The Guardian World", url: "https://www.theguardian.com/world/rss", type: "news", category: "World", enabled: true },
  { id: "W5", name: "DW News", url: "https://rss.dw.com/rdf/rss-en-all", type: "news", category: "World", enabled: true },
  { id: "W6", name: "France 24", url: "https://www.france24.com/en/rss", type: "news", category: "World", enabled: true },
  { id: "W7", name: "AP News World", url: "https://rsshub.app/apnews/topics/world-news", type: "news", category: "World", enabled: true },
  { id: "W8", name: "NPR World", url: "https://feeds.npr.org/1004/rss.xml", type: "news", category: "World", enabled: true },
  { id: "W9", name: "South China Morning Post", url: "https://www.scmp.com/rss/91/feed", type: "news", category: "World", enabled: true },
  { id: "W10", name: "Japan Times", url: "https://www.japantimes.co.jp/feed/", type: "news", category: "World", enabled: true },
  // US POLITICS
  { id: "P1", name: "Politico", url: "https://www.politico.com/rss/politicopicks.xml", type: "news", category: "US Politics", enabled: true },
  { id: "P2", name: "The Hill", url: "https://thehill.com/feed/", type: "news", category: "US Politics", enabled: true },
  { id: "P3", name: "Roll Call", url: "https://www.rollcall.com/feed/", type: "news", category: "US Politics", enabled: true },
  { id: "P4", name: "RealClearPolitics", url: "https://www.realclearpolitics.com/index.xml", type: "news", category: "US Politics", enabled: true },
  { id: "P5", name: "C-SPAN", url: "https://www.c-span.org/rss/", type: "news", category: "US Politics", enabled: true },
  { id: "P6", name: "Washington Post Politics", url: "https://feeds.washingtonpost.com/rss/politics", type: "news", category: "US Politics", enabled: true },
  { id: "P7", name: "NYT Politics", url: "https://rss.nytimes.com/services/xml/rss/nyt/Politics.xml", type: "news", category: "US Politics", enabled: true },
  { id: "P8", name: "Axios", url: "https://api.axios.com/feed/", type: "news", category: "US Politics", enabled: true },
  { id: "P9", name: "The Intercept", url: "https://theintercept.com/feed/?rss", type: "news", category: "US Politics", enabled: true },
  { id: "P10", name: "FiveThirtyEight", url: "https://fivethirtyeight.com/politics/feed/", type: "news", category: "US Politics", enabled: true },
  // TECH
  { id: "T1", name: "Hacker News", url: "https://news.ycombinator.com/rss", type: "news", category: "Tech", enabled: true },
  { id: "T2", name: "The Verge", url: "https://www.theverge.com/rss/index.xml", type: "news", category: "Tech", enabled: true },
  { id: "T3", name: "TechCrunch", url: "https://techcrunch.com/feed/", type: "news", category: "Tech", enabled: true },
  { id: "T4", name: "Ars Technica", url: "https://feeds.arstechnica.com/arstechnica/index", type: "news", category: "Tech", enabled: true },
  { id: "T5", name: "Wired", url: "https://www.wired.com/feed/rss", type: "news", category: "Tech", enabled: true },
  { id: "T6", name: "AnandTech", url: "https://www.anandtech.com/rss/", type: "news", category: "Tech", enabled: true },
  { id: "T7", name: "Tom's Hardware", url: "https://www.tomshardware.com/feeds/all", type: "news", category: "Tech", enabled: true },
  { id: "T8", name: "Engadget", url: "https://www.engadget.com/rss.xml", type: "news", category: "Tech", enabled: true },
  { id: "T9", name: "9to5Mac", url: "https://9to5mac.com/feed/", type: "news", category: "Tech", enabled: true },
  { id: "T10", name: "The Register", url: "https://www.theregister.com/headlines.atom", type: "news", category: "Tech", enabled: true },
  // AI
  { id: "A1", name: "OpenAI Blog", url: "https://openai.com/blog/rss.xml", type: "news", category: "AI", enabled: true },
  { id: "A2", name: "Google AI Blog", url: "https://blog.google/technology/ai/rss/", type: "news", category: "AI", enabled: true },
  { id: "A3", name: "Anthropic", url: "https://www.anthropic.com/feed", type: "news", category: "AI", enabled: true },
  { id: "A4", name: "Hugging Face Blog", url: "https://huggingface.co/blog/feed.xml", type: "news", category: "AI", enabled: true },
  { id: "A5", name: "AI Breakfast", url: "https://aibreakfast.beehiiv.com/feed", type: "news", category: "AI", enabled: true },
  { id: "A6", name: "The Batch", url: "https://www.deeplearning.ai/the-batch/feed/", type: "news", category: "AI", enabled: true },
  { id: "A7", name: "Import AI", url: "https://importai.substack.com/feed", type: "news", category: "AI", enabled: true },
  { id: "A8", name: "MIT Tech Review AI", url: "https://www.technologyreview.com/topic/artificial-intelligence/feed", type: "news", category: "AI", enabled: true },
  { id: "A9", name: "VentureBeat AI", url: "https://venturebeat.com/category/ai/feed/", type: "news", category: "AI", enabled: true },
  { id: "A10", name: "AI Weekly", url: "https://aiweekly.co/issues.rss", type: "news", category: "AI", enabled: true },
  // FINANCE
  { id: "F1", name: "Bloomberg", url: "https://feeds.bloomberg.com/markets/news.rss", type: "news", category: "Finance", enabled: true },
  { id: "F2", name: "CNBC", url: "https://www.cnbc.com/id/100003114/device/rss/rss.html", type: "news", category: "Finance", enabled: true },
  { id: "F3", name: "Financial Times", url: "https://www.ft.com/rss/home", type: "news", category: "Finance", enabled: true },
  { id: "F4", name: "MarketWatch", url: "https://feeds.marketwatch.com/marketwatch/topstories/", type: "news", category: "Finance", enabled: true },
  { id: "F5", name: "WSJ Markets", url: "https://feeds.a.dj.com/rss/RSSMarketsMain.xml", type: "news", category: "Finance", enabled: true },
  { id: "F6", name: "Yahoo Finance", url: "https://finance.yahoo.com/rss/", type: "news", category: "Finance", enabled: true },
  { id: "F7", name: "Seeking Alpha", url: "https://seekingalpha.com/market_currents.xml", type: "news", category: "Finance", enabled: true },
  { id: "F8", name: "The Motley Fool", url: "https://www.fool.com/feeds/index.aspx", type: "news", category: "Finance", enabled: true },
  { id: "F9", name: "Barron's", url: "https://www.barrons.com/rss", type: "news", category: "Finance", enabled: true },
  { id: "F10", name: "Investopedia", url: "https://www.investopedia.com/feedbuilder/feed/getfeed?feedName=rss_headline", type: "news", category: "Finance", enabled: true },
  // SCIENCE
  { id: "S1", name: "NASA", url: "https://www.nasa.gov/rss/dyn/breaking_news.rss", type: "news", category: "Science", enabled: true },
  { id: "S2", name: "Nature", url: "https://www.nature.com/nature.rss", type: "news", category: "Science", enabled: true },
  { id: "S3", name: "Science Daily", url: "https://www.sciencedaily.com/rss/all.xml", type: "news", category: "Science", enabled: true },
  { id: "S4", name: "New Scientist", url: "https://www.newscientist.com/feed/home/", type: "news", category: "Science", enabled: true },
  { id: "S5", name: "Phys.org", url: "https://phys.org/rss-feed/", type: "news", category: "Science", enabled: true },
  { id: "S6", name: "Ars Technica Science", url: "https://feeds.arstechnica.com/arstechnica/science", type: "news", category: "Science", enabled: true },
  { id: "S7", name: "Popular Science", url: "https://www.popsci.com/feed/", type: "news", category: "Science", enabled: true },
  { id: "S8", name: "Scientific American", url: "https://www.scientificamerican.com/feed/", type: "news", category: "Science", enabled: true },
  { id: "S9", name: "Live Science", url: "https://www.livescience.com/feeds/all", type: "news", category: "Science", enabled: true },
  { id: "S10", name: "MIT Tech Review", url: "https://www.technologyreview.com/feed/", type: "news", category: "Science", enabled: true }
];
async function fetchAndParseRSS(url) {
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(1e4) });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const text = await response.text();
    const items = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    let match;
    while ((match = itemRegex.exec(text)) !== null) {
      const itemContent = match[1];
      const getTag = (tag) => {
        const r = new RegExp(`<${tag}.*?>(.*?)</${tag}>`, "s");
        const m = r.exec(itemContent);
        return m ? m[1].trim().replace(/<!\[CDATA\[(.*?)\]\]>/g, "$1") : "";
      };
      const enclosureMatch = /<enclosure[^>]*url=["']([^"']*)[^>]*type=["']([^"']*)/i.exec(itemContent);
      items.push({
        title: getTag("title"),
        link: getTag("link"),
        contentSnippet: getTag("description").replace(/<[^>]*>/g, "").substring(0, 500),
        pubDate: getTag("pubDate"),
        enclosure: enclosureMatch ? { url: enclosureMatch[1], type: enclosureMatch[2] } : void 0
      });
    }
    return items;
  } catch (e) {
    console.warn(`Failed to parse RSS from ${url}:`, e);
    return [];
  }
}
var DEFAULT_CATEGORY_PRIORITIES = [
  "Breaking News",
  "AI",
  "Tech",
  "Local",
  "World",
  "Business",
  "Science",
  "Finance",
  "Politics",
  "Health"
];
var NewsService = class {
  dataDir;
  briefingsDir;
  gemini;
  elevenLabsApiKey;
  inworldApiKey;
  inworldSecret;
  inworldVoices;
  voicePersonalities;
  categoryPriorities;
  constructor(dataDir, geminiApiKey, elevenLabsApiKey, inworldApiKey, inworldSecret, inworldVoicesStr, voicePersonalities, categoryPriorities) {
    this.dataDir = dataDir;
    this.briefingsDir = join(dataDir, "briefings");
    this.gemini = new GoogleGenerativeAI(geminiApiKey);
    this.elevenLabsApiKey = elevenLabsApiKey;
    this.inworldApiKey = inworldApiKey;
    this.inworldSecret = inworldSecret;
    this.inworldVoices = inworldVoicesStr ? inworldVoicesStr.split(",").map((v) => v.trim()).filter((v) => v) : ["Ashley"];
    this.voicePersonalities = voicePersonalities || [];
    this.categoryPriorities = categoryPriorities || DEFAULT_CATEGORY_PRIORITIES;
    if (!existsSync(this.dataDir)) mkdirSync(this.dataDir, { recursive: true });
    if (!existsSync(this.briefingsDir)) mkdirSync(this.briefingsDir, { recursive: true });
  }
  getSources() {
    return HARDCODED_SOURCES;
  }
  getBriefing(date) {
    const file = join(this.briefingsDir, `${date}.json`);
    if (existsSync(file)) {
      return JSON.parse(readFileSync(file, "utf8"));
    }
    return null;
  }
  async generateDailyBriefing(force = false) {
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    const existing = this.getBriefing(today);
    if (existing && !force) return existing;
    const sources = this.getSources().filter((s) => s.enabled);
    const articles = [];
    const podcastTracks = [];
    for (const source of sources) {
      const items = await fetchAndParseRSS(source.url);
      items.slice(0, 2).forEach((item) => {
        let enclosure = void 0;
        if (item.enclosure?.type?.startsWith("audio")) {
          enclosure = { url: item.enclosure.url, type: item.enclosure.type };
          if (source.type === "podcast") {
            podcastTracks.push({
              title: item.title || "Podcast Episode",
              url: item.enclosure.url,
              type: "podcast"
            });
          }
        }
        articles.push({
          title: item.title || "",
          link: item.link || "",
          snippet: item.contentSnippet || "",
          sourceName: source.name,
          category: source.category,
          enclosure,
          pubDate: item.pubDate || ""
        });
      });
    }
    articles.sort((a, b) => {
      const priorityA = this.categoryPriorities.indexOf(a.category);
      const priorityB = this.categoryPriorities.indexOf(b.category);
      const orderA = priorityA === -1 ? 999 : priorityA;
      const orderB = priorityB === -1 ? 999 : priorityB;
      return orderA - orderB;
    });
    console.log(`Sorted ${articles.length} articles by category priority: ${this.categoryPriorities.slice(0, 3).join(", ")}...`);
    let selectedPersonality = null;
    if (this.voicePersonalities.length > 0) {
      selectedPersonality = this.voicePersonalities[Math.floor(Math.random() * this.voicePersonalities.length)];
      console.log(`Using personality: ${selectedPersonality.name}`);
    }
    let summaryText = "No summary generated.";
    let narrativeScript = "";
    if (articles.length > 5) {
      try {
        const model = this.gemini.getGenerativeModel({ model: "gemini-2.0-flash" });
        const personalityInstruction = selectedPersonality ? `PERSONALITY: ${selectedPersonality.personality}

Present the news in this character's style and voice.

` : "";
        const prompt = `${personalityInstruction}You are a news anchor. Create a comprehensive daily briefing from the following headlines.

IMPORTANT: Create a COMPLETE narrative script that covers ALL the major headlines. The script should be 2-3 minutes when read aloud (about 300-500 words).

Respond with ONLY this exact JSON structure (no markdown, no extra text):
{"bulletPoints": "- Category: Headline summary\\n- Category: Another headline", "narrativeScript": "Good morning. Here's what's happening today. [Complete narrative covering all major stories]..."}

Headlines (sorted by priority):
${articles.slice(0, 40).map((a) => `[${a.category}] ${a.title}`).join("\n")}`;
        const result = await model.generateContent(prompt);
        let responseText = result.response.text().trim();
        if (responseText.startsWith("```")) {
          responseText = responseText.replace(/^```(?:json)?\s*/i, "").replace(/\s*```\s*$/, "");
        }
        let content = null;
        try {
          content = JSON.parse(responseText);
          console.log("JSON parsed successfully");
        } catch (e) {
          console.log("Direct JSON parse failed:", e.message?.substring(0, 100));
          const jsonStart = responseText.indexOf("{");
          const jsonEnd = responseText.lastIndexOf("}");
          if (jsonStart !== -1 && jsonEnd > jsonStart) {
            try {
              content = JSON.parse(responseText.substring(jsonStart, jsonEnd + 1));
              console.log("JSON extracted and parsed successfully");
            } catch (e2) {
              console.log("JSON extraction also failed:", e2.message?.substring(0, 100));
            }
          }
        }
        if (content && content.bulletPoints) {
          summaryText = content.bulletPoints;
          narrativeScript = content.narrativeScript || "";
          console.log(`Narrative length: ${narrativeScript.length} chars`);
        } else {
          const narrativeStartMatch = responseText.match(/"narrativeScript"\s*:\s*"/i);
          if (narrativeStartMatch) {
            const startIdx = responseText.indexOf(narrativeStartMatch[0]) + narrativeStartMatch[0].length;
            let endIdx = startIdx;
            let inEscape = false;
            for (let i = startIdx; i < responseText.length; i++) {
              if (inEscape) {
                inEscape = false;
                continue;
              }
              if (responseText[i] === "\\") {
                inEscape = true;
                continue;
              }
              if (responseText[i] === '"') {
                endIdx = i;
                break;
              }
            }
            if (endIdx > startIdx) {
              narrativeScript = responseText.substring(startIdx, endIdx).replace(/\\n/g, " ").replace(/\\"/g, '"').trim();
              console.log(`Extracted narrative from raw JSON: ${narrativeScript.length} chars`);
            }
          }
          summaryText = responseText.length > 50 ? responseText : "Summary generated.";
          if (!narrativeScript || narrativeScript.length < 50) {
            console.log("No valid narrative found, skipping TTS");
            narrativeScript = "";
          }
        }
      } catch (e) {
        console.error("Gemini Error:", e);
        summaryText = "Error generating summary.";
      }
    }
    let summaryAudioUrl = "";
    if (this.inworldApiKey && this.inworldSecret && narrativeScript) {
      try {
        console.log("Generating audio with Inworld TTS...");
        summaryAudioUrl = await this.generateInworldAudio(narrativeScript, selectedPersonality);
      } catch (e) {
        console.error("Inworld Audio generation failed:", e);
        if (this.elevenLabsApiKey) {
          console.log("Falling back to ElevenLabs TTS...");
          summaryAudioUrl = await this.generateElevenLabsAudio(narrativeScript);
        }
      }
    } else if (this.elevenLabsApiKey && narrativeScript) {
      try {
        summaryAudioUrl = await this.generateElevenLabsAudio(narrativeScript);
      } catch (e) {
        console.error("Audio generation failed", e);
      }
    }
    const audioPlaylist = [];
    if (summaryAudioUrl) {
      audioPlaylist.push({ title: "Daily Summary", url: summaryAudioUrl, type: "summary" });
    }
    audioPlaylist.push(...podcastTracks);
    const briefing = {
      date: today,
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      summaryText,
      audioPlaylist,
      articles
    };
    writeFileSync(join(this.briefingsDir, `${today}.json`), JSON.stringify(briefing, null, 2));
    return briefing;
  }
  async generateInworldAudio(text, personality) {
    const url = "https://api.inworld.ai/tts/v1/voice";
    const credentials = Buffer.from(`${this.inworldApiKey}:${this.inworldSecret}`).toString("base64");
    let selectedVoice;
    if (personality && personality.voiceId) {
      selectedVoice = personality.voiceId;
      console.log(`Inworld TTS using personality voice: ${personality.name} (${selectedVoice})`);
    } else {
      selectedVoice = this.inworldVoices[Math.floor(Math.random() * this.inworldVoices.length)];
      console.log(`Inworld TTS using random voice: ${selectedVoice} (from ${this.inworldVoices.length} options)`);
    }
    const MAX_CHUNK = 1800;
    const chunks = [];
    let remaining = text;
    while (remaining.length > 0) {
      if (remaining.length <= MAX_CHUNK) {
        chunks.push(remaining);
        break;
      }
      let splitPoint = MAX_CHUNK;
      const lastPeriod = remaining.lastIndexOf(".", MAX_CHUNK);
      const lastExclaim = remaining.lastIndexOf("!", MAX_CHUNK);
      const lastQuestion = remaining.lastIndexOf("?", MAX_CHUNK);
      const bestSentenceEnd = Math.max(lastPeriod, lastExclaim, lastQuestion);
      if (bestSentenceEnd > MAX_CHUNK * 0.5) {
        splitPoint = bestSentenceEnd + 1;
      }
      chunks.push(remaining.substring(0, splitPoint).trim());
      remaining = remaining.substring(splitPoint).trim();
    }
    console.log(`Inworld TTS: splitting into ${chunks.length} parts (total ${text.length} chars)`);
    const audioBuffers = [];
    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      console.log(`Generating part ${i + 1}/${chunks.length} (${chunk.length} chars)...`);
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Authorization": `Basic ${credentials}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          text: chunk,
          voiceId: selectedVoice,
          modelId: "inworld-tts-1"
        })
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Inworld TTS error ${response.status}: ${errorText}`);
      }
      const result = await response.json();
      if (!result.audioContent) {
        throw new Error("Inworld TTS response missing audioContent");
      }
      audioBuffers.push(Buffer.from(result.audioContent, "base64"));
    }
    const combinedAudio = Buffer.concat(audioBuffers);
    const filename = `inworld-summary-${Date.now()}.mp3`;
    const audioDir = join(this.dataDir, "audio");
    if (!existsSync(audioDir)) mkdirSync(audioDir, { recursive: true });
    writeFileSync(join(audioDir, filename), combinedAudio);
    console.log(`Inworld TTS audio saved: ${filename} (${combinedAudio.length} bytes, ${chunks.length} parts)`);
    return `/api/audio/${filename}`;
  }
  async generateElevenLabsAudio(text) {
    const voiceId = "21m00Tcm4TlvDq8ikWAM";
    const url = `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`;
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "xi-api-key": this.elevenLabsApiKey || "",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        text: text.substring(0, 5e3),
        // ElevenLabs limit
        model_id: "eleven_monolingual_v1",
        voice_settings: { stability: 0.5, similarity_boost: 0.5 }
      })
    });
    if (!response.ok) throw new Error(`ElevenLabs error: ${response.statusText}`);
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const filename = `summary-${Date.now()}.mp3`;
    const audioDir = join(this.dataDir, "audio");
    if (!existsSync(audioDir)) mkdirSync(audioDir, { recursive: true });
    writeFileSync(join(audioDir, filename), buffer);
    return `/api/audio/${filename}`;
  }
};

// src/server.ts
var serverDistFolder = dirname(fileURLToPath(import.meta.url));
var browserDistFolder = resolve(serverDistFolder, "../browser");
var app = express();
app.post("/api/chat/inworld", async (req, res) => {
});
app.get("/api/voice/session", async (req, res) => {
  if (!appConfig.inworldApiKey || !appConfig.inworldSecret) {
    res.status(503).json({ error: "Inworld API keys not configured" });
    return;
  }
  let personaName = "ARIA";
  if (appConfig.inworldVoicePersonalities && appConfig.inworldVoicePersonalities.length > 0) {
    personaName = appConfig.inworldVoicePersonalities[0].name;
  }
  try {
    const credentials = Buffer.from(`${appConfig.inworldApiKey}:${appConfig.inworldSecret}`).toString("base64");
    const tokenResponse = await fetch("https://api.inworld.ai/v1/generate_token", {
      method: "POST",
      headers: {
        "Authorization": `Basic ${credentials}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        // detailed configuration can be passed here if needed
      })
    });
    if (!tokenResponse.ok) {
      const err = await tokenResponse.text();
      console.error("Inworld token error:", err);
      res.status(tokenResponse.status).json({ error: "Failed to authenticate with Inworld" });
      return;
    }
    const tokenData = await tokenResponse.json();
    res.json({
      wsUrl: "wss://api.inworld.ai/v1/session",
      sessionId: tokenData.sessionId,
      accessToken: tokenData.token,
      // Client needs this for WebSocket Auth
      persona: personaName,
      configured: true,
      scene: appConfig.inworldScene
      // Pass scene to client if available
    });
  } catch (err) {
    console.error("Voice session error:", err);
    res.status(500).json({ error: err.message });
  }
});
var resourcesFile = join2(os.homedir(), ".portal-resources.json");
var configFile = join2(os.homedir(), ".portal-config.json");
var traderEnvFile = join2(os.homedir(), ".trader-config.env");
function writeTraderEnv(config) {
  const lines = [];
  if (config.alpacaKeyId) lines.push(`ALPACA_API_KEY_ID=${config.alpacaKeyId}`);
  if (config.alpacaSecretKey) lines.push(`ALPACA_API_SECRET_KEY=${config.alpacaSecretKey}`);
  if (config.openaiApiKey) lines.push(`OPENAI_API_KEY=${config.openaiApiKey}`);
  writeFileSync2(traderEnvFile, lines.join("\n") + "\n");
}
function readConfig() {
  try {
    if (existsSync2(configFile)) {
      return JSON.parse(readFileSync2(configFile, "utf8"));
    }
  } catch (e) {
    console.error("Error reading config:", e);
  }
  return {};
}
function saveConfig(config) {
  writeFileSync2(configFile, JSON.stringify(config, null, 2));
}
var appConfig = readConfig();
if (process.env["GEMINI_API_KEY"] && !appConfig.geminiApiKey) {
  appConfig.geminiApiKey = process.env["GEMINI_API_KEY"];
}
if (process.env["ELEVENLABS_API_KEY"] && !appConfig.elevenLabsApiKey) {
  appConfig.elevenLabsApiKey = process.env["ELEVENLABS_API_KEY"];
}
var newsService = null;
function initializeServices() {
  if (appConfig.geminiApiKey) {
    newsService = new NewsService(
      join2(serverDistFolder, "data"),
      appConfig.geminiApiKey,
      appConfig.elevenLabsApiKey,
      appConfig.inworldApiKey,
      appConfig.inworldSecret,
      appConfig.inworldVoices,
      appConfig.inworldVoicePersonalities,
      appConfig.categoryPriorities
    );
    return true;
  }
  return false;
}
initializeServices();
function readResources() {
  try {
    return JSON.parse(readFileSync2(resourcesFile, "utf8"));
  } catch {
    return [];
  }
}
function writeResources(data) {
  writeFileSync2(resourcesFile, JSON.stringify(data, null, 2));
}
app.use(express.json());
app.get("/session", async (req, res) => {
  console.log(
    "Received session request process.env.OPENAI_API_KEY",
    process.env["OPENAI_API_KEY"]
  );
  try {
    const r = await fetch("https://api.openai.com/v1/realtime/sessions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env["OPENAI_API_KEY"]}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini-realtime-preview-2024-12-17",
        voice: "shimmer"
      })
    });
    const data = await r.json();
    console.log("Received session response", data);
    res.send(data);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Session fetch failed" });
  }
});
app.get("/api/config", (req, res) => {
  res.json({
    hasGemini: !!appConfig.geminiApiKey,
    hasElevenLabs: !!appConfig.elevenLabsApiKey,
    hasInworld: !!appConfig.inworldApiKey && !!appConfig.inworldSecret,
    hasAlpaca: !!appConfig.alpacaKeyId && !!appConfig.alpacaSecretKey,
    hasOpenAI: !!appConfig.openaiApiKey,
    servicesInitialized: !!newsService
  });
});
app.post("/api/config", (req, res) => {
  const { geminiApiKey, elevenLabsApiKey, inworldApiKey, inworldSecret, inworldVoices, inworldVoicePersonalities, categoryPriorities, alpacaKeyId, alpacaSecretKey, openaiApiKey } = req.body;
  if (geminiApiKey) {
    appConfig.geminiApiKey = geminiApiKey;
  }
  if (elevenLabsApiKey !== void 0) {
    appConfig.elevenLabsApiKey = elevenLabsApiKey || void 0;
  }
  if (inworldApiKey !== void 0) {
    appConfig.inworldApiKey = inworldApiKey || void 0;
  }
  if (inworldSecret !== void 0) {
    appConfig.inworldSecret = inworldSecret || void 0;
  }
  if (inworldVoices !== void 0) {
    appConfig.inworldVoices = inworldVoices || void 0;
  }
  if (inworldVoicePersonalities !== void 0) {
    appConfig.inworldVoicePersonalities = inworldVoicePersonalities || void 0;
  }
  if (categoryPriorities !== void 0) {
    appConfig.categoryPriorities = categoryPriorities || void 0;
  }
  if (alpacaKeyId !== void 0) {
    appConfig.alpacaKeyId = alpacaKeyId || void 0;
  }
  if (alpacaSecretKey !== void 0) {
    appConfig.alpacaSecretKey = alpacaSecretKey || void 0;
  }
  if (openaiApiKey !== void 0) {
    appConfig.openaiApiKey = openaiApiKey || void 0;
  }
  saveConfig(appConfig);
  if (appConfig.alpacaKeyId || appConfig.alpacaSecretKey || appConfig.openaiApiKey) {
    writeTraderEnv(appConfig);
  }
  const initialized = initializeServices();
  res.json({
    success: true,
    initialized,
    hasGemini: !!appConfig.geminiApiKey,
    hasElevenLabs: !!appConfig.elevenLabsApiKey,
    hasInworld: !!appConfig.inworldApiKey && !!appConfig.inworldSecret,
    hasAlpaca: !!appConfig.alpacaKeyId && !!appConfig.alpacaSecretKey,
    hasOpenAI: !!appConfig.openaiApiKey
  });
});
app.delete("/api/config", (req, res) => {
  appConfig = {};
  saveConfig(appConfig);
  newsService = null;
  res.json({ success: true, message: "Configuration cleared" });
});
var MANAGED_SERVICES = ["portal", "alpaca-trader"];
function getServiceStatus(serviceName) {
  try {
    const activeResult = execSync(`systemctl is-active ${serviceName} 2>/dev/null || true`, { encoding: "utf8" }).trim();
    const enabledResult = execSync(`systemctl is-enabled ${serviceName} 2>/dev/null || true`, { encoding: "utf8" }).trim();
    return {
      active: activeResult === "active",
      enabled: enabledResult === "enabled",
      status: activeResult
    };
  } catch {
    return { active: false, enabled: false, status: "unknown" };
  }
}
app.get("/api/services", (req, res) => {
  const services = MANAGED_SERVICES.map((name) => ({
    name,
    ...getServiceStatus(name)
  }));
  res.json(services);
});
app.post("/api/services/:name/:action", (req, res) => {
  const { name, action } = req.params;
  if (!MANAGED_SERVICES.includes(name)) {
    res.status(400).json({ error: `Unknown service: ${name}` });
    return;
  }
  const validActions = ["start", "stop", "restart", "enable", "disable"];
  if (!validActions.includes(action)) {
    res.status(400).json({ error: `Invalid action: ${action}` });
    return;
  }
  try {
    execSync(`sudo systemctl ${action} ${name}`, { encoding: "utf8" });
    const status = getServiceStatus(name);
    res.json({ success: true, service: name, action, ...status });
  } catch (err) {
    console.error(`Service ${action} failed for ${name}:`, err);
    res.status(500).json({ error: `Failed to ${action} ${name}`, details: err.message });
  }
});
var systemCronFile = "/etc/cron.d/portal-jobs";
app.get("/api/cron/user", (req, res) => {
  try {
    const crontab = execSync('crontab -l 2>/dev/null || echo ""', { encoding: "utf8" });
    res.json({ crontab: crontab.trim() });
  } catch (err) {
    res.json({ crontab: "", error: err.message });
  }
});
app.post("/api/cron/user", (req, res) => {
  try {
    const { crontab } = req.body;
    if (typeof crontab !== "string") {
      res.status(400).json({ error: "Invalid crontab content" });
      return;
    }
    const tempFile = "/tmp/portal-crontab-" + Date.now();
    writeFileSync2(tempFile, crontab + "\n");
    execSync(`crontab ${tempFile}`, { encoding: "utf8" });
    execSync(`rm ${tempFile}`);
    res.json({ success: true, message: "User crontab updated" });
  } catch (err) {
    console.error("Failed to update user crontab:", err);
    res.status(500).json({ error: err.message });
  }
});
app.get("/api/cron/system", (req, res) => {
  try {
    if (existsSync2(systemCronFile)) {
      const crontab = readFileSync2(systemCronFile, "utf8");
      res.json({ crontab: crontab.trim() });
    } else {
      res.json({ crontab: "" });
    }
  } catch (err) {
    res.json({ crontab: "", error: err.message });
  }
});
app.post("/api/cron/system", (req, res) => {
  try {
    const { crontab } = req.body;
    if (typeof crontab !== "string") {
      res.status(400).json({ error: "Invalid crontab content" });
      return;
    }
    const tempFile = "/tmp/portal-system-cron-" + Date.now();
    writeFileSync2(tempFile, crontab + "\n");
    execSync(`sudo mv ${tempFile} ${systemCronFile} && sudo chmod 644 ${systemCronFile}`, { encoding: "utf8" });
    res.json({ success: true, message: "System crontab updated" });
  } catch (err) {
    console.error("Failed to update system crontab:", err);
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/news/generate", async (req, res) => {
  if (!newsService) {
    res.status(503).json({ error: "News service not initialized. Check API keys." });
    return;
  }
  try {
    console.log("Triggering news generation...");
    const briefing = await newsService.generateDailyBriefing(true);
    res.json({ success: true, date: briefing.date, articlesCount: briefing.articles.length });
  } catch (err) {
    console.error("News generation failed:", err);
    res.status(500).json({ error: err.message });
  }
});
function getSystemStatus() {
  try {
    const cpuInfo = execSync("top -bn1 | grep 'Cpu(s)' | awk '{print $2}'", { encoding: "utf8" }).trim();
    const memInfo = execSync(`free -m | awk 'NR==2{printf "%sMB / %sMB", $3, $2}'`, { encoding: "utf8" }).trim();
    const tempInfo = execSync(`cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null | awk '{printf "%.1fC", $1/1000}'`, { encoding: "utf8" }).trim() || "N/A";
    const uptime = execSync("uptime -p", { encoding: "utf8" }).trim();
    const services = ["portal", "alpaca-trader", "caddy"];
    const serviceStatus = services.map((s) => {
      try {
        const active = execSync(`systemctl is-active ${s} 2>/dev/null`, { encoding: "utf8" }).trim();
        return `${s}: ${active}`;
      } catch {
        return `${s}: inactive`;
      }
    }).join(", ");
    return `SYSTEM STATUS:
- CPU Usage: ${cpuInfo}%
- Memory: ${memInfo}
- Temperature: ${tempInfo}
- Uptime: ${uptime}
- Services: ${serviceStatus}`;
  } catch (e) {
    return "System status unavailable";
  }
}
app.post("/api/chat/inworld", async (req, res) => {
  const { message, history = [] } = req.body;
  if (!message) {
    res.status(400).json({ error: "Message is required" });
    return;
  }
  if (!appConfig.geminiApiKey) {
    res.status(503).json({ error: "Gemini API not configured. Add key in Settings." });
    return;
  }
  try {
    let persona = { name: "ARIA", personality: "You are ARIA, an AI assistant for the Raspberry Pi portal. You are friendly, helpful, and technically knowledgeable." };
    if (appConfig.inworldVoicePersonalities && appConfig.inworldVoicePersonalities.length > 0) {
      const p = appConfig.inworldVoicePersonalities[0];
      persona = { name: p.name, personality: p.personality };
    }
    const systemStatus = getSystemStatus();
    const systemPrompt = `${persona.personality}

You are connected to a Raspberry Pi Zero 2 portal dashboard. You can provide information about the system status.

${systemStatus}

Current time: ${(/* @__PURE__ */ new Date()).toLocaleString("en-US", { timeZone: "Pacific/Honolulu" })} (Hawaii Time)

Answer user questions helpfully while staying in character. Keep responses concise but informative. If asked about system status, use the information above.`;
    const contents = [];
    for (const msg of history.slice(-10)) {
      contents.push({
        role: msg.role === "assistant" ? "model" : "user",
        parts: [{ text: msg.content }]
      });
    }
    contents.push({
      role: "user",
      parts: [{ text: message }]
    });
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${appConfig.geminiApiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents,
          systemInstruction: { parts: [{ text: systemPrompt }] }
        })
      }
    );
    if (!response.ok) {
      const errorText = await response.text();
      console.error("Gemini API error:", response.status, errorText);
      res.status(response.status).json({ error: `Chat API error: ${response.status}` });
      return;
    }
    const result = await response.json();
    const reply = result.candidates?.[0]?.content?.parts?.[0]?.text || "No response from assistant.";
    res.json({
      reply,
      persona: persona.name,
      systemStatus: systemStatus.split("\n").slice(1).join(", ").substring(0, 100)
    });
  } catch (err) {
    console.error("Chat error:", err);
    res.status(500).json({ error: err.message });
  }
});
var contingentOrdersFile = join2(os.homedir(), "projects/trader/contingent_orders.json");
async function alpacaRequest(endpoint, method = "GET", body) {
  if (!existsSync2(traderEnvFile)) {
    throw new Error("Trading not configured");
  }
  const envContent = readFileSync2(traderEnvFile, "utf8");
  const keyMatch = envContent.match(/ALPACA_API_KEY_ID=(.+)/);
  const secretMatch = envContent.match(/ALPACA_API_SECRET_KEY=(.+)/);
  if (!keyMatch || !secretMatch) {
    throw new Error("Alpaca keys not found");
  }
  const isPaper = true;
  const baseUrl = isPaper ? "https://paper-api.alpaca.markets" : "https://api.alpaca.markets";
  const response = await fetch(`${baseUrl}${endpoint}`, {
    method,
    headers: {
      "APCA-API-KEY-ID": keyMatch[1].trim(),
      "APCA-API-SECRET-KEY": secretMatch[1].trim(),
      "Content-Type": "application/json"
    },
    body: body ? JSON.stringify(body) : void 0
  });
  if (!response.ok) {
    throw new Error(`Alpaca API error: ${response.status}`);
  }
  return response.json();
}
app.get("/api/trading/status", async (req, res) => {
  try {
    const [account, positions] = await Promise.all([
      alpacaRequest("/v2/account"),
      alpacaRequest("/v2/positions")
    ]);
    let botRunning = false;
    try {
      const status = execSync("systemctl is-active alpaca-trader 2>/dev/null || true", { encoding: "utf8" }).trim();
      botRunning = status === "active";
    } catch {
    }
    res.json({
      botRunning,
      cash: parseFloat(account.cash),
      equity: parseFloat(account.equity),
      dayPL: parseFloat(account.equity) - parseFloat(account.last_equity),
      positions: positions.map((p) => ({
        symbol: p.symbol,
        qty: parseFloat(p.qty),
        current_price: parseFloat(p.current_price),
        avg_entry_price: parseFloat(p.avg_entry_price),
        unrealized_pl: parseFloat(p.unrealized_pl),
        unrealized_plpc: parseFloat(p.unrealized_plpc)
      })),
      lastUpdate: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (err) {
    console.error("Trading status error:", err);
    res.status(503).json({ error: err.message });
  }
});
app.get("/api/trading/contingent", (req, res) => {
  try {
    if (existsSync2(contingentOrdersFile)) {
      const orders = JSON.parse(readFileSync2(contingentOrdersFile, "utf8"));
      res.json(orders);
    } else {
      res.json([]);
    }
  } catch (err) {
    res.json([]);
  }
});
app.post("/api/trading/contingent", (req, res) => {
  try {
    const { symbol, condition, value, action, notional, qty_pct } = req.body;
    if (!symbol || !condition || !value || !action) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }
    let orders = [];
    if (existsSync2(contingentOrdersFile)) {
      orders = JSON.parse(readFileSync2(contingentOrdersFile, "utf8"));
    }
    orders.push({
      symbol: symbol.toUpperCase(),
      condition,
      value: parseFloat(value),
      action,
      notional: notional ? parseFloat(notional) : 50,
      qty_pct: qty_pct ? parseFloat(qty_pct) : 100,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    });
    writeFileSync2(contingentOrdersFile, JSON.stringify(orders, null, 2));
    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.delete("/api/trading/contingent/:index", (req, res) => {
  try {
    const index = parseInt(req.params.index);
    if (existsSync2(contingentOrdersFile)) {
      let orders = JSON.parse(readFileSync2(contingentOrdersFile, "utf8"));
      if (index >= 0 && index < orders.length) {
        orders.splice(index, 1);
        writeFileSync2(contingentOrdersFile, JSON.stringify(orders, null, 2));
        res.json({ success: true, orders });
      } else {
        res.status(404).json({ error: "Order not found" });
      }
    } else {
      res.status(404).json({ error: "No orders found" });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.post("/api/update-repo", (req, res) => {
  const home = os.homedir();
  const repoUrl = "https://github.com/yourusername/RaspberryZero2_Portal.git";
  const repoPath = join2(home, "RaspberryZero2_Portal");
  try {
    if (!existsSync2(repoPath)) {
      execSync(`git clone ${repoUrl} ${repoPath}`);
    } else {
      execSync(`git -C ${repoPath} pull`, { stdio: "inherit" });
    }
    const branch = `update-${Date.now()}`;
    execSync(`git -C ${repoPath} checkout -b ${branch}`);
    execSync(`git -C ${repoPath} add .`);
    execSync(`git -C ${repoPath} commit -m "Automated update"`);
    res.json({ message: "Repository updated", branch });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update repository" });
  }
});
app.post("/api/deploy", (req, res) => {
  const home = os.homedir();
  const repoPath = join2(home, "RaspberryZero2_Portal");
  try {
    execSync("npm run build", { cwd: repoPath, stdio: "inherit" });
    const distPath = join2(repoPath, "dist", "raspberry-zero2-portal");
    execSync(`cp -r ${distPath}/* ${home}/`);
    res.json({ message: "Deployment complete" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to deploy" });
  }
});
app.get("/api/resources", (req, res) => {
  const resources = readResources().sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  res.json(resources);
});
app.post("/api/resources", (req, res) => {
  const resources = readResources();
  const entry = {
    id: Date.now().toString(),
    content: req.body.content,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  resources.unshift(entry);
  writeResources(resources);
  res.json(entry);
});
app.delete("/api/resources/:id", (req, res) => {
  let resources = readResources();
  const id = req.params["id"];
  const beforeLength = resources.length;
  resources = resources.filter((r) => r.id !== id);
  writeResources(resources);
  res.json({ success: resources.length !== beforeLength });
});
app.get("/api/news", async (req, res) => {
  if (!newsService) {
    res.status(503).json({
      error: "News service not configured",
      message: "Please configure API keys in settings"
    });
    return;
  }
  try {
    const force = req.query["force"] === "true";
    const briefing = await newsService.generateDailyBriefing(force);
    res.json(briefing);
  } catch (err) {
    console.error("News Error:", err);
    res.status(500).json({ error: "Failed to generate briefing" });
  }
});
app.post("/api/news/refresh", async (req, res) => {
  if (!newsService) {
    res.status(503).json({
      error: "News service not initialized",
      needsConfig: true,
      message: "Please configure Gemini API key in settings"
    });
    return;
  }
  try {
    console.log("Manual news refresh triggered...");
    const briefing = await newsService.generateDailyBriefing(true);
    res.json(briefing);
  } catch (err) {
    console.error("News Refresh Error:", err);
    res.status(500).json({ error: "Failed to regenerate briefing" });
  }
});
app.get("/api/audio/:filename", (req, res) => {
  const filePath = join2(serverDistFolder, "data/audio", req.params.filename);
  if (existsSync2(filePath)) {
    res.sendFile(filePath);
  } else {
    res.status(404).send("Audio not found");
  }
});
app.get("/api/news/sources", (req, res) => {
  if (!newsService) {
    res.status(503).json({ error: "News service not configured" });
    return;
  }
  res.json(newsService.getSources());
});
app.use(
  express.static(browserDistFolder, {
    maxAge: "1y",
    index: false,
    redirect: false
  })
);
app.get("**", (req, res, next) => {
  if (req.url.startsWith("/api/")) {
    return next();
  }
  res.sendFile(join2(browserDistFolder, "index.html"));
});
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const port = process.env["PORT"] || 4e3;
  const host = "0.0.0.0";
  app.listen(Number(port), host, () => {
    console.log(`Node Express server listening on http://${host}:${port}`);
  });
}
var server_default = app;
export {
  server_default as default
};
/*! Bundled license information:

@google/generative-ai/dist/index.mjs:
@google/generative-ai/dist/index.mjs:
  (**
   * @license
   * Copyright 2024 Google LLC
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *   http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   *)
*/
