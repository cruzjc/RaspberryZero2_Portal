
export default {
  bootstrap: () => import('./main.server.mjs').then(m => m.default),
  inlineCriticalCss: true,
  baseHref: '/',
  locale: undefined,
  routes: [
  {
    "renderMode": 2,
    "route": "/news"
  },
  {
    "renderMode": 2,
    "route": "/news-settings"
  },
  {
    "renderMode": 2,
    "route": "/admin"
  }
],
  entryPointToBrowserMapping: undefined,
  assets: {
    'index.csr.html': {size: 1406, hash: '63c62fb1767063d56be0f001cf96da5aea07d534acb5860ff210d7662ff082cf', text: () => import('./assets-chunks/index_csr_html.mjs').then(m => m.default)},
    'index.server.html': {size: 1017, hash: '1101c48d6d804610a6d0dff5c49bf8c3597b3a6a00a686d0ab66acae13b2a36c', text: () => import('./assets-chunks/index_server_html.mjs').then(m => m.default)},
    'news/index.html': {size: 24002, hash: 'f0e19fbc97f56066e3eee5276ddf40bf26ff7182323e0485dc4b378a728a42b4', text: () => import('./assets-chunks/news_index_html.mjs').then(m => m.default)},
    'news-settings/index.html': {size: 21771, hash: 'bde1033ec34c8e192ed968e3b31aa773e8bc9457ecc4e875ccca43d33af82977', text: () => import('./assets-chunks/news-settings_index_html.mjs').then(m => m.default)},
    'admin/index.html': {size: 20512, hash: '5d3ca3c2eeed0c876b24c04635835d6181ae0b5f5f2109427a007f128201e34f', text: () => import('./assets-chunks/admin_index_html.mjs').then(m => m.default)},
    'styles-PBXOPXW4.css': {size: 1885, hash: '3MJYabWerH4', text: () => import('./assets-chunks/styles-PBXOPXW4_css.mjs').then(m => m.default)}
  },
};
