export default `<!doctype html>
<html lang="en" data-beasties-container="">
<head>
  <meta charset="utf-8">
  <title>RaspberryZero2Portal</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="favicon.ico">
<style>:root{--bg-gradient:linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%);--glass-bg:rgba(255, 255, 255, .05);--glass-border:rgba(255, 255, 255, .1);--glass-shadow:0 8px 32px 0 rgba(0, 0, 0, .37);--text-primary:#ffffff;--text-secondary:rgba(255, 255, 255, .7);--accent-color:#4facfe;--accent-gradient:linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);--danger-color:#ff6b6b;--success-color:#51cf66;--spacing-xs:4px;--spacing-sm:8px;--spacing-md:16px;--spacing-lg:24px;--spacing-xl:32px;--radius-sm:8px;--radius-md:16px;--radius-lg:24px}*{box-sizing:border-box;margin:0;padding:0}body{font-family:Inter,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,sans-serif;background:var(--bg-gradient);color:var(--text-primary);min-height:100vh;line-height:1.6}</style><link rel="stylesheet" href="styles-PBXOPXW4.css" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="styles-PBXOPXW4.css"></noscript></head>
<body ngcm="">
  <app-root></app-root>
<script src="polyfills-B6TNHZQ6.js" type="module"></script><script src="main-E6LTESUU.js" type="module"></script></body>
</html>
`;