
export default {
  bootstrap: () => import('./main.server.mjs').then(m => m.default),
  inlineCriticalCss: true,
  baseHref: '/',
  locale: undefined,
  routes: [
  {
    "renderMode": 0,
    "route": "/news"
  },
  {
    "renderMode": 0,
    "route": "/news-settings"
  },
  {
    "renderMode": 0,
    "route": "/admin"
  }
],
  entryPointToBrowserMapping: undefined,
  assets: {
    'index.csr.html': {size: 1406, hash: '2b55e4ddc76ece2231c9adec099210a63bb7d3b9ee8e08d5f403f9770acac5bd', text: () => import('./assets-chunks/index_csr_html.mjs').then(m => m.default)},
    'index.server.html': {size: 1017, hash: '9112faab5258ea1e7e5e77c8e707343ec3b8793a036c53ee7767d97d8ec69d30', text: () => import('./assets-chunks/index_server_html.mjs').then(m => m.default)},
    'styles-PBXOPXW4.css': {size: 1885, hash: '3MJYabWerH4', text: () => import('./assets-chunks/styles-PBXOPXW4_css.mjs').then(m => m.default)}
  },
};
